# Readme

Original code (main branch) forked from https://github.com/automata-network/automata-dcap-v3-attestation and applied some gas optimizations here: https://github.com/smtmfft/automata-dcap-v3-attestation/tree/parse-quote-offline, which then got merged into taiko-mono.
The corresponding upstream PR is: https://github.com/automata-network/automata-dcap-v3-attestation/pull/6, waiting to be merged.
