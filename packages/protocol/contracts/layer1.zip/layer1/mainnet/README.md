# Optimized Smart Contracts for Taiko Mainnet

## Overview

This directory contains optimized versions of smart contracts for deployment on Ethereum for Taiko mainnet. While some of these contracts may be used on Taiko L2, deployment on Layer 2 is not recommended due to lack of testing.
