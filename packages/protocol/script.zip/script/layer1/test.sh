## Set exact environment variables
#export PRIVATE_KEY=0xd9df9cba5738197719214dd4c42cb3f0e17215f8b1245c1d25e60b3282fe82c8
#export SGX_VERIFIER_ADDRESS=0xb9a56842396069207269ab55d36751fbfb789821
#export ATTESTATION_ADDRESS=0xb80af4889b6bf6ca21b36acf3a958589dbf6bd48
#export PEM_CERTCHAIN_ADDRESS=0x28779ec140ebcf8dd417edd26cb4069147935827
#
#
## Set task flag (only enable setting MrEnclave for now, not other operations)
#export TASK_ENABLE=1,0,0,0,0,0
#
## Set MrEnclave value
#export MR_ENCLAVE=0xa1f665149dfa955b443f3cc7d05ec3ea02d679621f0c8b7e4462f703d3866edf
#export MR_SIGNER=0xca0583a715534a8c981b914589a7f0dc5d60959d9ae79fb5353299a4231673d5
#
## Execute forge script directly
#forge script script/layer1/SetDcapParams.s.sol:SetDcapParams \
#    --broadcast \
#    --evm-version cancun \
#    --ffi \
#    -vvvv \
#    --private-key ${PRIVATE_KEY}


# Set environment variables
export PRIVATE_KEY=0xd9df9cba5738197719214dd4c42cb3f0e17215f8b1245c1d25e60b3282fe82c8
export ATTESTATION_ADDRESS=0xb80af4889b6bf6ca21b36acf3a958589dbf6bd48
export FORK_URL=https://frequent-chaotic-energy.ethereum-hoodi.quiknode.pro/1638b088524738ffa6c8356f7d9f5e49b0d5b176

# Command to directly interact with the contract
cast send $ATTESTATION_ADDRESS "setMrEnclave(bytes32,bool)" \
  0xa1f665149dfa955b443f3cc7d05ec3ea02d679621f0c8b7e4462f703d3866edf true \
  --private-key $PRIVATE_KEY --rpc-url $FORK_URL
